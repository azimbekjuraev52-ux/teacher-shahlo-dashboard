# Dashboard sozlamalari. Hisoblash qoidalarini shu fayldan o'zgartiring.

SUBDOMAIN = "sayqaltalimcrm"          # https://sayqaltalimcrm.amocrm.ru
PIPELINE_ID = 11299394                # TEACHER SHAHLO voronkasi

# Ma'lumotni amoCRM'dan qayta tortish oralig'i (daqiqa)
REFRESH_MINUTES = 10

# Patok (oqim) teglari: "5.0", "6.0", "7.1" kabi raqamli teglar.
# Bular manba hisoblanmaydi, dashboard tepasidagi "Patok" filtri bo'ladi.
STREAM_TAG_REGEX = r"^\d+(\.\d+)?$"
# Standart ko'rinish. "" = Hammasi (barcha patok — amoCRM bilan bir xil sotuv soni).
# "5.0" qilsangiz, dashboard faqat 5.0 tegi bor lidlarni ko'rsatadi.
DEFAULT_STREAM = ""

# Manba bo'lmagan teglar (holat/texnik teglar). Ular manbani aniqlashda o'tkazib yuboriladi.
NON_SOURCE_TAGS = [
    "DUBLIKAT",
    "DUBLIKAT — tekshiring",
    "import-xato-28.09",
    "Onlayn qiziqdi",
    "Oflayn qiziqdi",
    "prepayment",
    "Клиент не ответил",
    "Исходящий",
    "lid",
]

# Bir xil manbaning turli yozilishlarini birlashtirish: {"eski nom": "yagona nom"}.
# Vebinarlar sanasi bo'yicha alohida qoldirildi (qaysi vebinar ko'p sotgani ko'rinsin).
TAG_ALIASES = {
    "INSTA | BIO": "Insta Bio",
    "INSTA | PROGREV": "IG Progrev",
    "Insta Progrev": "IG Progrev",
    "Tg lead": "Telegram leads",
    "Instagram leads": "Telegram leads",
}

# Manbasi yo'q lidlar shu nom bilan ko'rsatiladi
NO_SOURCE_LABEL = "Manbasiz"

# Kvalifikatsiya: shu statusga YETGAN lidlar "gaplashilgan" hisoblanadi.
# "Gaplashilgan konversiya" maxraji = shu status va undan keyingilar + sifatli otkaz lidlar.
# Undan oldingilar (Неразобранное, Yangi lead, Ishga olindi), sifatsiz va sababsiz lost chiqariladi.
QUALIFY_STATUS_NAME = "ALOQA O'RNATILDI"

# Lost sabablari. Sabab nomida shu so'zlardan biri bo'lsa, lid o'sha guruhga tushadi.
# Solishtirishda katta-kichik harf, apostroflar (' ’ ʻ) va "-", "/" belgilari e'tiborga olinmaydi.

# Sotuvdan keyingi lost: budjet kiritilgan, keyin to'xtatilgan. Bular sotuv hisobida qoladi,
# foizi sotuvlar soniga nisbatan hisoblanadi. Ular sifatli otkaz ham hisoblanadi.
SALE_LOSS_GROUPS = [
    ("vozvrat", "Vozvrat", ["vozvrat", "возврат", "qaytarildi"]),
    ("otkaz", "To'lov otkaz", ["otkaz", "отказ"]),
    ("muzlatilgan", "Muzlatilgan", ["muzlat"]),
]

# Sifatli otkaz: mijoz mos, lekin olmadi (amoCRM'dagi haqiqiy sabab nomlari)
SIFATLI_REASONS = [
    "qimmat",            # Qimmat / byudjet yetmadi
    "byudjet yetmadi",
    "tashqi to'siq",     # Tashqi to'siq (oila/ish/ruxsat)
    "keyingi oqimda",    # Keyingi oqimda o'qiydi
]

# Sifatsiz lid: konversiya sifatli hisobidan chiqariladi (amoCRM'dagi haqiqiy nomlar)
SIFATSIZ_REASONS = [
    "dubl kartochka",    # Texnik: dubl kartochka
    "maqsadli emas",     # Maqsadli emas (ustoz/ekspert emas)
    "aloqaga chiqmadi",
    "boshqa kursni",     # Boshqa kursni tanladi
    "onlaynga qiziqmaydi",
    "to'ldirilmagan",    # ⚠️ To'ldirilmagan
]

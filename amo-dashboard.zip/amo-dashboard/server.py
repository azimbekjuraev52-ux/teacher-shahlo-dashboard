"""amoCRM dashboard serveri.

Ishga tushirish:  python3 server.py
Keyin brauzerda:   http://127.0.0.1:8050

.env faylida AMO_TOKEN bo'lmasa, demo ma'lumot ko'rsatiladi.
"""
import base64
import json
import os
import random
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

import config

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
CACHE_FILE = os.path.join(BASE_DIR, "data", "cache.json")
# Cloud (Render/Railway) $PORT beradi; lokalда 8050.
PORT = int(os.environ.get("PORT", "8050"))
# Barcha IP'lardan kirish uchun 0.0.0.0 (cloudда kerak), lokalда ham ishlaydi.
HOST = os.environ.get("HOST", "0.0.0.0")


def expected_auth():
    """DASH_USER/DASH_PASS o'rnatilgan bo'lsa, kutilgan Basic-auth sarlavhasini qaytaradi."""
    user = os.environ.get("DASH_USER")
    pw = os.environ.get("DASH_PASS")
    if user and pw:
        token = base64.b64encode(("%s:%s" % (user, pw)).encode("utf-8")).decode("ascii")
        return "Basic " + token
    return None


def load_env():
    path = os.path.join(BASE_DIR, ".env")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# ---------- amoCRM API ----------

class AmoClient:
    def __init__(self, subdomain, token):
        self.base = "https://%s.amocrm.ru/api/v4" % subdomain
        self.token = token

    def get(self, path, params=None):
        url = self.base + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + self.token})
        time.sleep(0.2)  # amoCRM limiti: sekundiga 7 ta so'rov
        with urllib.request.urlopen(req, timeout=30) as resp:
            if resp.status == 204:
                return None
            return json.loads(resp.read().decode("utf-8"))

    def get_all(self, path, key, params=None):
        items, page = [], 1
        while True:
            p = dict(params or {}, limit=250, page=page)
            data = self.get(path, p)
            if not data:
                break
            batch = data.get("_embedded", {}).get(key, [])
            items.extend(batch)
            if len(batch) < 250 or "next" not in data.get("_links", {}):
                break
            page += 1
        return items


def fetch_from_amo(token):
    amo = AmoClient(config.SUBDOMAIN, token)
    pipeline = amo.get("/leads/pipelines/%d" % config.PIPELINE_ID)
    statuses = sorted(pipeline["_embedded"]["statuses"], key=lambda s: s["sort"])
    users = {u["id"]: u["name"] for u in amo.get_all("/users", "users")}
    raw = amo.get_all("/leads", "leads", {
        "filter[pipeline_id]": config.PIPELINE_ID,
        "with": "loss_reason",
    })
    leads = []
    for l in raw:
        emb = l.get("_embedded", {})
        reasons = emb.get("loss_reason") or []
        leads.append({
            "id": l["id"],
            "price": l.get("price") or 0,
            "status_id": l["status_id"],
            "user": users.get(l.get("responsible_user_id"), "Noma'lum"),
            "created": l.get("created_at"),
            "closed": l.get("closed_at"),
            "tags": [t["name"] for t in emb.get("tags") or []],
            "loss_reason": reasons[0]["name"] if reasons else None,
        })
    return statuses, leads


# ---------- Demo ma'lumot (token bo'lmaganda) ----------

def demo_data():
    rnd = random.Random(42)
    statuses = [
        (1, "Yangi lead", 947), (2, "Ishga olindi", 876), (3, "Aloqa o'rnatildi", 343),
        (4, "Ma'lumot berildi", 192), (5, "Qiziqish bildirdi", 352), (6, "Hisob yuborildi", 55),
        (7, "Vozvrat", 2), (8, "Predoplata", 95), (9, "50% To'lov", 18),
        (142, "Won", 80), (143, "Lost", 972),
    ]
    status_list = [{"id": sid, "name": n, "sort": i * 10} for i, (sid, n, _) in enumerate(statuses)]
    users = ["Dilsora", "Madina", "Hayotxon", "Charos", "Farangiz", "ADMIN"]
    sources = ["Vebinar", "IG Progrev", "DM Intsa", "Vebinar | 26.10", "Insta Bio", "TG progrev",
               "WB | Sayt", "DM progrev", "DM Telegram", "Telegram leads", "Reels", "VSL"]
    weights = [773, 449, 433, 291, 283, 252, 249, 174, 154, 113, 50, 22]
    lost_reasons = [("Без причины", 14), ("Bog'lanib bo'lmadi", 22), ("Noto'g'ri raqam", 10),
                    ("Che't el raqam bog'lanib bo'lmadi", 3), ("Boshqa kursda o'qiydi", 4),
                    ("Offline kerak", 2), ("Dublikat", 5), ("Test qildi", 1), ("Darajasi yuqori", 2),
                    ("Maqsadsiz ro'yxatdan o'tgan", 6), ("Puli yo'q", 15),
                    ("Ota ona ruxsat bermadi", 5), ("Kursga o'qishga vaqti yo'q", 9)]
    start = datetime(2026, 8, 1)
    leads, lid = [], 1000
    for sid, _, count in statuses:
        for _ in range(count):
            lid += 1
            created = start + timedelta(days=rnd.random() * 92, minutes=rnd.randint(0, 1440))
            tags = []
            if rnd.random() < 0.78:
                tags.append("5.0")
            tags.append(rnd.choices(sources, weights)[0])
            if rnd.random() < 0.1:
                tags.append(rnd.choice(["Onlayn qiziqdi", "DUBLIKAT", "Bonus"]))
            price, reason, closed = 0, None, None
            if sid in (7, 8, 9, 142):
                price = rnd.choice([100000, 200000, 330000, 800000, 1000000, 1200000, 1380000])
            if sid in (142, 143):
                closed = created + timedelta(days=rnd.uniform(0.2, 40))
            if sid == 143:
                r = rnd.random()
                if r < 0.012:
                    reason = "Vozvrat qilindi"
                elif r < 0.024:
                    reason = "To'lov otkaz"
                elif r < 0.034:
                    reason = "Muzlatilgan"
                else:
                    reason = rnd.choices([n for n, _ in lost_reasons], [w for _, w in lost_reasons])[0]
                if reason in ("Vozvrat qilindi", "To'lov otkaz", "Muzlatilgan"):
                    price = rnd.choice([200000, 800000, 1200000])
            leads.append({
                "id": lid, "price": price, "status_id": sid, "user": rnd.choice(users),
                "created": int(created.timestamp()),
                "closed": int(closed.timestamp()) if closed else None,
                "tags": tags, "loss_reason": reason,
            })
    return status_list, leads


# ---------- Hisoblash qoidalari ----------

STREAM_RE = re.compile(config.STREAM_TAG_REGEX)
NON_SOURCE = {t.lower() for t in config.NON_SOURCE_TAGS}


def norm(text):
    text = re.sub(r"['’ʻʼ`‘]", "", text.lower())
    return " ".join(re.sub(r"[-/]", " ", text).split())


SALE_GROUPS = [(key, [norm(w) for w in words]) for key, _, words in config.SALE_LOSS_GROUPS]
SIFATLI = [norm(w) for w in config.SIFATLI_REASONS]
SIFATSIZ = [norm(w) for w in config.SIFATSIZ_REASONS]


def classify_reason(reason):
    """(sotuvdan keyingi guruh, sifat) qaytaradi. Sifat: "sifatsiz", "sifatli" yoki None."""
    if not reason:
        return None, None
    r = norm(reason)
    for key, words in SALE_GROUPS:
        if any(w in r for w in words):
            return key, "sifatli"
    if any(w in r for w in SIFATSIZ):
        return None, "sifatsiz"
    if any(w in r for w in SIFATLI):
        return None, "sifatli"
    return None, None


def normalize(statuses, leads):
    order = {s["id"]: i for i, s in enumerate(statuses)}
    qname = norm(config.QUALIFY_STATUS_NAME)
    qorder = next((i for i, s in enumerate(statuses) if norm(s["name"]) == qname), None)
    out = []
    for l in leads:
        streams = [t for t in l["tags"] if STREAM_RE.match(t)]
        source = next((config.TAG_ALIASES.get(t, t) for t in l["tags"]
                       if not STREAM_RE.match(t) and t.lower() not in NON_SOURCE),
                      config.NO_SOURCE_LABEL)
        if l["status_id"] == 142:
            stype = "won"
        elif l["status_id"] == 143:
            stype = "lost"
        else:
            stype = "open"
        group, quality = classify_reason(l["loss_reason"]) if stype == "lost" else (None, None)
        # Har bir lid faqat bitta turga tushadi: jami = jarayonda + sotuv + sifatsiz + sifatli + boshqa
        if l["price"] > 0 or group:
            kind = "sotuv"
        elif stype == "open":
            kind = "jarayonda"
        else:
            kind = quality or "boshqa"
        # Kvalifikatsiya (gaplashilgan konversiya maxraji):
        # won + sifatli lost + ochiq lidlar "Aloqa o'rnatildi" va undan keyingi bosqichda.
        # Sifatsiz va sababsiz lost, hamda aloqa o'rnatilmagan erta bosqichlar — tashqarida.
        if stype == "won":
            qualified = True
        elif stype == "lost":
            qualified = quality == "sifatli"
        else:
            qualified = qorder is not None and order.get(l["status_id"], -1) >= qorder
        out.append({
            "id": l["id"], "price": l["price"], "status_id": l["status_id"], "user": l["user"],
            "created": l["created"], "closed": l["closed"], "streams": streams, "source": source,
            "loss_reason": l["loss_reason"], "loss_group": group, "quality": quality,
            "won": stype == "won", "kind": kind, "qualified": qualified,
        })
    return {
        "statuses": [{"id": s["id"], "name": s["name"]} for s in statuses],
        "default_stream": config.DEFAULT_STREAM,
        "subdomain": config.SUBDOMAIN,
        "leads": out,
    }


# ---------- Kesh va fon yangilash ----------

state = {"payload": None, "synced_at": None, "error": None, "demo": True}
lock = threading.Lock()


def sync():
    token = os.environ.get("AMO_TOKEN")
    try:
        if token:
            statuses, leads = fetch_from_amo(token)
        else:
            statuses, leads = demo_data()
        payload = normalize(statuses, leads)
        with lock:
            state.update(payload=payload, synced_at=int(time.time()), error=None, demo=not token)
        if token:
            os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump({"synced_at": state["synced_at"], "payload": payload}, f, ensure_ascii=False)
        print("[%s] Yangilandi: %d ta lid%s" % (time.strftime("%H:%M:%S"), len(leads),
                                               "" if token else " (demo)"))
    except urllib.error.HTTPError as e:
        msg = "amoCRM xatosi %d: %s" % (e.code, "token noto'g'ri yoki muddati o'tgan" if e.code == 401 else e.reason)
        with lock:
            state["error"] = msg
        print(msg)
    except Exception as e:  # tarmoq xatosi va h.k. — eski kesh ko'rinib turadi
        with lock:
            state["error"] = str(e)
        print("Xato:", e)


def load_cache():
    if os.environ.get("AMO_TOKEN") and os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        state.update(payload=data["payload"], synced_at=data["synced_at"], demo=False)


def refresher():
    while True:
        time.sleep(config.REFRESH_MINUTES * 60)
        sync()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def send_json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self):
        """DASH_USER/DASH_PASS o'rnatilgan bo'lsa, login/parol so'raydi."""
        expected = expected_auth()
        if expected is None:
            return True  # parol sozlanmagan — ochiq (lokal rejim)
        if self.headers.get("Authorization") == expected:
            return True
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="TEACHER SHAHLO dashboard"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def do_GET(self):
        if not self.authorized():
            return
        if self.path.startswith("/api/data"):
            with lock:
                self.send_json(dict(state["payload"] or {}, synced_at=state["synced_at"],
                                    error=state["error"], demo=state["demo"]))
        elif self.path.startswith("/api/refresh"):
            sync()
            self.send_json({"ok": state["error"] is None, "error": state["error"]})
        else:
            super().do_GET()

    def log_message(self, *args):
        pass


def startup_sync():
    """Birinchi sync + davriy yangilash — fonda, server darhol ochilsin."""
    sync()
    refresher()


if __name__ == "__main__":
    load_env()
    load_cache()
    # Birinchi sync'ni fonga olamiz: cloud port'ni tez ochishimizni kutadi.
    threading.Thread(target=startup_sync, daemon=True).start()
    if expected_auth():
        print("Parol himoyasi: YONIQ (DASH_USER/DASH_PASS)")
    print("Dashboard: http://%s:%d" % (HOST, PORT))
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
